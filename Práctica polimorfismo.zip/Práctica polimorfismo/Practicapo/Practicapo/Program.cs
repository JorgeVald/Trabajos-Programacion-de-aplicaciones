﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practicapo
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangulo rec = new Rectangulo();
            rec.Area(34, 56);
            Triangulo tri = new Triangulo();
            tri.Area(34, 56);
            System.Threading.Thread.Sleep(2000);
        }
    }
}
