﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practicapo
{
    class Triangulo : Rectangulo
    {
        public void Area(int Base, int Altura)
        {
            Console.WriteLine("El área de mi triángulo es: "+((Base*Altura)/2));
        }
    }
}
