﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UsoCoches//nombre del proyecto
{
    class Program
    {
        static void Main(string[] args)//método principal, encargado de ejecutar las acciones del programa
        {
            System.Threading.Thread.Sleep(1000);//Da una pausa entre una ejecución y otra

            Coche coche1 = new Coche();//creación del objeto coche1, con el tipo de datos Coche
            Coche coche2 = new Coche();//creación del objeto coche2, con el tipo de datos Coche

            Console.WriteLine(coche1.getRuedas());//imprime el número de ruedas en el coche1
            Console.WriteLine(coche2.getRuedas());//imprime el número de ruedas en el coche2
            //El número de ruedas es el mismo, ya que no se cambian los valores para ningún objeto
            System.Threading.Thread.Sleep(1000);

            Console.WriteLine(coche1.getInfoCoche());//imprime la información del coche1
            Console.WriteLine(coche2.getInfoCoche());//imprime la información del coche2
            //la información es la misma, ya que no se cambian los valores de las variables para ningún objeto

            System.Threading.Thread.Sleep(1000);

            Console.WriteLine("Fin del programa");//Imprime el mensaje 'Fin del programa'
        }
        class Coche//creación de la clase coche, con la cual crearemos varios objetos
        {
            public Coche()//método constructor de la clase coche
            {
                ruedas = 4;//asignación de valor a la variable ruedas
                largo = 2300.5;//asignación de valor a la variable largo
                ancho = 0.800;//asignación de valor a la variable ancho
            }
            private int ruedas;
            private double largo;
            private bool clima;
            private double ancho;
            private string tapiceria;
            /*Creación de las variables ruedas, largo, ancho, clima y tapicería
             todas las variables se declaran como variables privadas
             la variable clima y tapicería salen con una línea verde porque no son usadas    */
            public int getRuedas()//método get que nos permite obtener el valor de la variavle ruedas, en un número entero (int)
            {
                return ruedas;//regresa la variable ruedas
            }
            public string getInfoCoche()//método get para obtener información del coche, en una cadena de caracteres (String)
            {
                return "Información del coche:\nRuedas: " + ruedas + "\nLargo: " + largo + "\nAncho: " + ancho;//regresa lo que esta entre las comillas
            }
        }
    }
}
