﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Práctica_General
{
    class Ballena : Mamiferos//se crea la hereda de la clase Mamiferos
    {
        public void nadar()//se crea un método propio del animal, que en este caso es nadar
        {
            Console.WriteLine("La ballena está nadando");//imprime un mensaje
        }
    }
}
