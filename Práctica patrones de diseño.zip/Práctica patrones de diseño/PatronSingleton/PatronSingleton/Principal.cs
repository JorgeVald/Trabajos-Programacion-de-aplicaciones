﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PatronSingleton
{
    public partial class Principal : Form
    {
        public Principal()
        {
            InitializeComponent();
        }

        private void formulario1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //El siguiente fragmento de código, sirve para llamar al formulario1 cuando se seleccione
            Formulario1 fo = new Formulario1();
            fo.MdiParent = this;
            fo.Show();
        }

        private void formulario2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //El siguiente fragmento de código, sirve para llamar al formulario2 cuando se seleccione
            Formulario2 fu = Formulario2.ObtenerInstancia();//Llama el método para crear el formulario2
            fu.MdiParent = this;
            fu.Show();
        }
    }
}
