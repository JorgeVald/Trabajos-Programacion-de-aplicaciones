﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Single
{
    class Program
    {
        static void Main(string[] args)
        {
            Singleton m = new Singleton(25);
            for (int i = 0; i <= 10; i++){
                m.DiNumero();
            }
        }
    }
}
